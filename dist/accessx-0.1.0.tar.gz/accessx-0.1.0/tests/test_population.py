import geopandas as gpd
import numpy as np
import rasterio
from rasterio.transform import from_origin
from shapely.geometry import box

from accessx.population import (
    _validate_raster_file,
    map_population_grid_to_hexes,
    map_population_to_hexes,
    raster_to_population_grid,
)


def test_raster_to_population_grid_returns_one_polygon_per_valid_cell(tmp_path):
    raster_path = tmp_path / "population.tif"
    raster_values = np.array([[1, 2], [3, 4]], dtype="float32")

    with rasterio.open(
        raster_path,
        "w",
        driver="GTiff",
        height=2,
        width=2,
        count=1,
        dtype="float32",
        crs="EPSG:3857",
        transform=from_origin(0, 2, 1, 1),
        nodata=-9999,
    ) as dst:
        dst.write(raster_values, 1)

    grid = raster_to_population_grid(raster_path)

    assert len(grid) == 4
    assert sorted(grid["population"].tolist()) == [1.0, 2.0, 3.0, 4.0]
    assert grid.crs.to_string() == "EPSG:3857"


def test_map_population_to_hexes_splits_population_by_overlap_area(tmp_path):
    raster_path = tmp_path / "population.tif"

    with rasterio.open(
        raster_path,
        "w",
        driver="GTiff",
        height=1,
        width=1,
        count=1,
        dtype="float32",
        crs="EPSG:3857",
        transform=from_origin(0, 1, 1, 1),
        nodata=-9999,
    ) as dst:
        dst.write(np.array([[100]], dtype="float32"), 1)

    hexes = gpd.GeoDataFrame(
        {
            "hex_id": ["left", "right"],
            "geometry": [
                box(0, 0, 0.5, 1),
                box(0.5, 0, 1, 1),
            ],
        },
        crs="EPSG:3857",
    )

    result = map_population_to_hexes(
        hexes,
        raster_path,
        metric_crs="EPSG:3857",
    ).set_index("hex_id")

    assert result.loc["left", "population"] == 50.0
    assert result.loc["right", "population"] == 50.0
    assert result["population"].sum() == 100.0


def test_map_population_to_hexes_accepts_population_grid(tmp_path):
    raster_path = tmp_path / "population.tif"
    raster_values = np.array([[1, 2], [3, 4]], dtype="float32")

    with rasterio.open(
        raster_path,
        "w",
        driver="GTiff",
        height=2,
        width=2,
        count=1,
        dtype="float32",
        crs="EPSG:3857",
        transform=from_origin(0, 2, 1, 1),
        nodata=-9999,
    ) as dst:
        dst.write(raster_values, 1)

    population_grid = raster_to_population_grid(raster_path)
    hexes = gpd.GeoDataFrame(
        {
            "hex_id": ["all"],
            "geometry": [box(0, 0, 2, 2)],
        },
        crs="EPSG:3857",
    )

    result = map_population_to_hexes(
        hexes,
        population_grid,
        metric_crs="EPSG:3857",
    )

    assert result.loc[0, "population"] == 10.0


def test_map_population_grid_to_hexes_supports_multiple_population_groups():
    population_grid = gpd.GeoDataFrame(
        {
            "population": [100.0],
            "children": [20.0],
            "elderly": [10.0],
            "geometry": [box(0, 0, 1, 1)],
        },
        crs="EPSG:3857",
    )

    hexes = gpd.GeoDataFrame(
        {
            "hex_id": ["left", "right"],
            "geometry": [
                box(0, 0, 0.5, 1),
                box(0.5, 0, 1, 1),
            ],
        },
        crs="EPSG:3857",
    )

    result = map_population_grid_to_hexes(
        hexes,
        population_grid,
        metric_crs="EPSG:3857",
        population_cols=["population", "children", "elderly"],
    ).set_index("hex_id")

    assert result.loc["left", "population"] == 50.0
    assert result.loc["right", "population"] == 50.0
    assert result.loc["left", "children"] == 10.0
    assert result.loc["right", "children"] == 10.0
    assert result.loc["left", "elderly"] == 5.0
    assert result.loc["right", "elderly"] == 5.0


def test_map_population_to_hexes_returns_zero_when_no_overlap(tmp_path):
    raster_path = tmp_path / "population.tif"

    with rasterio.open(
        raster_path,
        "w",
        driver="GTiff",
        height=1,
        width=1,
        count=1,
        dtype="float32",
        crs="EPSG:3857",
        transform=from_origin(0, 1, 1, 1),
        nodata=-9999,
    ) as dst:
        dst.write(np.array([[5]], dtype="float32"), 1)

    hexes = gpd.GeoDataFrame(
        {
            "hex_id": ["outside"],
            "geometry": [box(10, 10, 11, 11)],
        },
        crs="EPSG:3857",
    )

    result = map_population_to_hexes(
        hexes,
        raster_path,
        metric_crs="EPSG:3857",
    )
    assert result.loc[0, "population"] == 0.0


def test_validate_raster_file_raises_on_invalid_tiff(tmp_path):
    raster_path = tmp_path / "worldpop_test.tif"
    raster_path.write_bytes(b"corrupted")

    try:
        _validate_raster_file(raster_path)
        assert False, "Expected raster validation to fail for an invalid TIFF."
    except Exception:
        assert True
