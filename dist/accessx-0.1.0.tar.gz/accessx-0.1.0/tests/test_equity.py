import math

import pandas as pd

from accessx.equity import calculate_lorenz


def test_calculate_lorenz_unweighted_matches_expected_simple_case():
    df = pd.DataFrame({"access": [0, 10]})

    _, _, gini, _ = calculate_lorenz(properties=["access"], df=df)

    assert math.isclose(gini["access"], 0.5, rel_tol=1e-9, abs_tol=1e-9)


def test_calculate_lorenz_population_weighted_changes_people_based_gini():
    df = pd.DataFrame(
        {
            "access": [0, 10],
            "population": [90, 10],
        }
    )

    _, population_share, gini, _ = calculate_lorenz(
        properties=["access"],
        df=df,
        weights="population",
    )

    assert math.isclose(population_share["access"][1], 0.9, rel_tol=1e-9, abs_tol=1e-9)
    assert math.isclose(gini["access"], 0.9, rel_tol=1e-9, abs_tol=1e-9)


def test_calculate_lorenz_weighted_rejects_negative_weights():
    df = pd.DataFrame(
        {
            "access": [1, 2],
            "population": [5, -1],
        }
    )

    try:
        calculate_lorenz(properties=["access"], df=df, weights="population")
        assert False, "Expected negative weights to raise an error."
    except ValueError as exc:
        assert "weights must be >= 0" in str(exc)
