import math

import geopandas as gpd
import networkx as nx
from shapely.geometry import Point

from accessx.accessibility import compute_co_accessibility


def _build_test_graph() -> nx.MultiDiGraph:
    graph = nx.MultiDiGraph()
    graph.graph["crs"] = "EPSG:3857"

    graph.add_node(1, x=0.0, y=0.0)
    graph.add_node(2, x=1.0, y=0.0)
    graph.add_node(3, x=2.0, y=0.0)

    for u, v in [(1, 2), (2, 1), (2, 3), (3, 2)]:
        graph.add_edge(u, v, avg_time=1.0)

    return graph


def test_compute_co_accessibility_cumulative_counts_population_groups():
    graph = _build_test_graph()

    hexes = gpd.GeoDataFrame(
        {
            "hex_id": ["h1", "h2"],
            "population": [10.0, 20.0],
            "children": [2.0, 5.0],
            "geometry": [Point(0.0, 0.0), Point(1.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )

    pois = gpd.GeoDataFrame(
        {
            "id": ["p1", "p2"],
            "category": ["park", "park"],
            "geometry": [Point(1.0, 0.0), Point(2.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )

    result = compute_co_accessibility(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        population_groups=["population", "children"],
        poi_id_col="id",
        category_col="category",
        approach="cumulative",
    )

    row_p1 = result.loc[result["id"] == "p1"].iloc[0]
    row_p2 = result.loc[result["id"] == "p2"].iloc[0]

    assert row_p1["coacc_population"] == 30.0
    assert row_p1["coacc_children"] == 7.0
    assert row_p2["coacc_population"] == 20.0
    assert row_p2["coacc_children"] == 5.0


def test_compute_co_accessibility_hansen_applies_distance_decay():
    graph = _build_test_graph()

    hexes = gpd.GeoDataFrame(
        {
            "hex_id": ["h1", "h2"],
            "population": [10.0, 20.0],
            "geometry": [Point(0.0, 0.0), Point(1.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )

    pois = gpd.GeoDataFrame(
        {
            "id": ["p1"],
            "geometry": [Point(1.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )

    result = compute_co_accessibility(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        population_groups="population",
        poi_id_col="id",
        approach="hansen",
        beta=1.0,
    )

    expected = 20.0 + 10.0 * math.exp(-1.0)
    assert math.isclose(float(result.iloc[0]["coacc_population"]), expected, rel_tol=1e-9)
