import geopandas as gpd
import networkx as nx
import warnings
from shapely.geometry import Point

from accessx.accessibility import (
    compute_2sfca_accessibility,
    compute_hansen_accessibility,
    compute_nearest_poi_cost,
    count_accessible_pois,
)
from accessx.isochrone import calculate_isochrones


def _graph():
    graph = nx.MultiDiGraph()
    graph.graph["crs"] = "EPSG:3857"
    graph.add_node(1, x=0.0, y=0.0)
    graph.add_node(2, x=1.0, y=0.0)
    graph.add_edge(1, 2, avg_time=1.0)
    graph.add_edge(2, 1, avg_time=1.0)
    return graph


def _hexes():
    return gpd.GeoDataFrame(
        {
            "hex_id": ["h1", "h2"],
            "population": [10.0, 20.0],
            "geometry": [Point(0.0, 0.0), Point(1.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )


def _pois():
    return gpd.GeoDataFrame(
        {
            "id": ["p1"],
            "category": ["healthcare"],
            "geometry": [Point(1.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )


def test_accessibility_functions_accept_show_progress():
    graph = _graph()
    hexes = _hexes()
    pois = _pois()

    counts = count_accessible_pois(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        show_progress=True,
    )
    assert "count_healthcare" in counts.columns

    nearest = compute_nearest_poi_cost(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        show_progress=True,
    )
    assert "nearest_pois_healthcare" in nearest.columns

    hansen = compute_hansen_accessibility(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        show_progress=True,
    )
    assert "hansen_healthcare" in hansen.columns

    sfca = compute_2sfca_accessibility(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        demand_col="population",
        show_progress=True,
    )
    assert "sfca_healthcare" in sfca.columns


def test_calculate_isochrones_accepts_show_progress():
    result = calculate_isochrones(
        _graph(),
        _hexes()[["hex_id", "geometry"]],
        max_cost=1,
        interval_size=1,
        cost_attr="avg_time",
        city_epsg=3857,
        method="hull",
        show_progress=True,
    )

    assert "geom_avg_time_1" in result.columns


def test_calculate_isochrones_csv_export_does_not_warn_about_geometry(tmp_path):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        calculate_isochrones(
            _graph(),
            _hexes()[["hex_id", "geometry"]],
            max_cost=1,
            interval_size=1,
            cost_attr="avg_time",
            city_epsg=3857,
            method="hull",
            save_dir=tmp_path,
        )

    messages = [str(warning.message) for warning in caught]
    assert not any("Geometry column does not contain geometry" in message for message in messages)
    assert (tmp_path / "walksheds_hull_avg_time_1.csv").exists()
