import geopandas as gpd
import networkx as nx
import warnings
from shapely.geometry import Point
from shapely.geometry import box

from accessx.accessibility import (
    compute_2sfca_accessibility,
    compute_hansen_accessibility,
    compute_nearest_poi_cost,
    count_accessible_pois,
)
from accessx.cost import add_edge_cost, add_time_cost_constant_speed
from accessx.graph import build_network
from accessx.isochrone import calculate_isochrones


def _graph():
    graph = nx.MultiDiGraph()
    graph.graph["crs"] = "EPSG:3857"
    graph.add_node(1, x=0.0, y=0.0)
    graph.add_node(2, x=1.0, y=0.0)
    graph.add_edge(1, 2, avg_time=1.0)
    graph.add_edge(2, 1, avg_time=1.0)
    return graph


def _hexes():
    return gpd.GeoDataFrame(
        {
            "hex_id": ["h1", "h2"],
            "population": [10.0, 20.0],
            "geometry": [Point(0.0, 0.0), Point(1.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )


def _pois():
    return gpd.GeoDataFrame(
        {
            "id": ["p1"],
            "category": ["healthcare"],
            "geometry": [Point(1.0, 0.0)],
        },
        geometry="geometry",
        crs="EPSG:3857",
    )


def test_build_network_accepts_show_progress(monkeypatch):
    def fake_graph_from_polygon(*, polygon, network_type, simplify, retain_all):
        graph = nx.MultiDiGraph()
        graph.graph["crs"] = "EPSG:4326"
        graph.add_node(1, x=0.0, y=0.0)
        graph.add_node(2, x=1.0, y=0.0)
        graph.add_node(3, x=2.0, y=0.0)
        graph.add_edge(1, 2, length=1.0)
        return graph

    def fake_project_graph(graph, to_crs):
        graph.graph["crs"] = f"EPSG:{to_crs}"
        return graph

    monkeypatch.setattr("accessx.graph.ox.graph_from_polygon", fake_graph_from_polygon)
    monkeypatch.setattr("accessx.graph.ox.project_graph", fake_project_graph)

    aoi = gpd.GeoDataFrame(geometry=[box(0.0, 0.0, 1.0, 1.0)], crs="EPSG:4326")

    graph = build_network(
        aoi,
        city_epsg=3857,
        buffer_m=25,
        show_progress=True,
    )

    assert graph.graph["crs"] == "EPSG:3857"
    assert 3 not in graph.nodes


def test_cost_functions_accept_show_progress():
    graph = _graph()
    for _, _, _, data in graph.edges(keys=True, data=True):
        data["length"] = 90.0

    graph = add_time_cost_constant_speed(
        graph,
        speed_kmh=5.4,
        cost_col="walk_time",
        show_progress=True,
    )

    for _, _, _, data in graph.edges(keys=True, data=True):
        assert data["walk_time"] == 1.0

    graph = add_edge_cost(
        graph,
        cost_fn=lambda edge: edge["length"] * 2,
        cost_col="comfort_cost",
        show_progress=True,
    )

    for _, _, _, data in graph.edges(keys=True, data=True):
        assert data["comfort_cost"] == 180.0


def test_accessibility_functions_accept_show_progress():
    graph = _graph()
    hexes = _hexes()
    pois = _pois()

    counts = count_accessible_pois(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        show_progress=True,
    )
    assert "count_healthcare" in counts.columns

    nearest = compute_nearest_poi_cost(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        show_progress=True,
    )
    assert "nearest_pois_healthcare" in nearest.columns

    hansen = compute_hansen_accessibility(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        show_progress=True,
    )
    assert "hansen_healthcare" in hansen.columns

    sfca = compute_2sfca_accessibility(
        graph,
        hexes,
        pois,
        max_cost=1,
        cost_attr="avg_time",
        demand_col="population",
        show_progress=True,
    )
    assert "sfca_healthcare" in sfca.columns


def test_calculate_isochrones_accepts_show_progress():
    result = calculate_isochrones(
        _graph(),
        _hexes()[["hex_id", "geometry"]],
        max_cost=1,
        interval_size=1,
        cost_attr="avg_time",
        city_epsg=3857,
        method="hull",
        show_progress=True,
    )

    assert "geom_avg_time_1" in result.columns


def test_calculate_isochrones_save_dir_writes_only_gpkg(tmp_path):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        calculate_isochrones(
            _graph(),
            _hexes()[["hex_id", "geometry"]],
            max_cost=1,
            interval_size=1,
            cost_attr="avg_time",
            city_epsg=3857,
            method="hull",
            save_dir=tmp_path,
        )

    messages = [str(warning.message) for warning in caught]
    assert not any("Geometry column does not contain geometry" in message for message in messages)
    assert (tmp_path / "walksheds_hull_avg_time.gpkg").exists()
    assert not list(tmp_path.glob("*.csv"))


def test_calculate_isochrones_exports_qgis_friendly_gpkg_layers(tmp_path):
    calculate_isochrones(
        _graph(),
        _hexes()[["hex_id", "geometry"]],
        max_cost=2,
        interval_size=1,
        cost_attr="avg_time",
        city_epsg=3857,
        method="edges",
        save_dir=tmp_path,
    )

    gpkg_path = tmp_path / "walksheds_edges_avg_time.gpkg"
    assert gpkg_path.exists()

    origins = gpd.read_file(gpkg_path, layer="origins")
    walksheds_1 = gpd.read_file(gpkg_path, layer="walksheds_1")
    walksheds_2 = gpd.read_file(gpkg_path, layer="walksheds_2")

    assert list(origins.columns) == ["hex_id", "geometry"]
    assert {"hex_id", "threshold", "cost_attr", "geometry"}.issubset(walksheds_1.columns)
    assert set(walksheds_1["threshold"]) == {1}
    assert set(walksheds_2["threshold"]) == {2}
    assert set(walksheds_1["cost_attr"]) == {"avg_time"}
