import geopandas as gpd
import pandas as pd
import pytest
from shapely.geometry import Point, box

from accessx.poi import POIQueryError, get_pois_osm


def _aoi():
    return gpd.GeoDataFrame({"geometry": [box(0, 0, 1, 1)]}, crs="EPSG:4326")


def _osm_features(include_name=True):
    data = {"amenity": ["clinic"], "geometry": [Point(0.5, 0.5)]}
    if include_name:
        data["name"] = ["Clinic"]
    index = pd.MultiIndex.from_tuples(
        [("node", 123)],
        names=["element", "id"],
    )
    return gpd.GeoDataFrame(data, index=index, crs="EPSG:4326")


def test_get_pois_osm_retries_transient_query_errors(monkeypatch):
    calls = []

    def fake_features_from_polygon(*args, **kwargs):
        calls.append(1)
        if len(calls) == 1:
            raise TimeoutError("temporary timeout")
        return _osm_features()

    monkeypatch.setattr("accessx.poi.ox.features_from_polygon", fake_features_from_polygon)
    monkeypatch.setattr("accessx.poi.time.sleep", lambda seconds: None)

    with pytest.warns(RuntimeWarning, match="Retrying"):
        pois, report = get_pois_osm(
            _aoi(),
            osm_tags={"amenity": ["clinic"]},
            max_retries=1,
            return_report=True,
        )

    assert len(calls) == 2
    assert len(pois) == 1
    assert report["retrieved_counts"] == {"amenity": 1}
    assert report["failed_queries"] == []


def test_get_pois_osm_raises_clear_error_after_failed_retries(monkeypatch):
    def fake_features_from_polygon(*args, **kwargs):
        raise TimeoutError("temporary timeout")

    monkeypatch.setattr("accessx.poi.ox.features_from_polygon", fake_features_from_polygon)
    monkeypatch.setattr("accessx.poi.time.sleep", lambda seconds: None)

    with pytest.warns(RuntimeWarning, match="Retrying"):
        with pytest.raises(POIQueryError, match="amenity"):
            get_pois_osm(
                _aoi(),
                osm_tags={"amenity": ["clinic"]},
                max_retries=1,
            )


def test_get_pois_osm_report_tracks_empty_osm_tags(monkeypatch):
    def fake_features_from_polygon(*args, tags=None, **kwargs):
        if tags == {"amenity": ["clinic"]}:
            return _osm_features()
        return gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs="EPSG:4326")

    monkeypatch.setattr("accessx.poi.ox.features_from_polygon", fake_features_from_polygon)
    monkeypatch.setattr("accessx.poi.time.sleep", lambda seconds: None)

    pois, report = get_pois_osm(
        _aoi(),
        osm_tags={"amenity": ["clinic"], "leisure": ["park"]},
        max_retries=0,
        return_report=True,
    )

    assert pois["category"].tolist() == ["amenity"]
    assert pois["subcategory"].tolist() == ["clinic"]
    assert report["empty_queries"] == ["leisure"]
    assert report["failed_queries"] == []


def test_get_pois_osm_minimal_columns_handles_missing_name(monkeypatch):
    monkeypatch.setattr(
        "accessx.poi.ox.features_from_polygon",
        lambda *args, **kwargs: _osm_features(include_name=False),
    )

    pois = get_pois_osm(
        _aoi(),
        osm_tags={"amenity": ["clinic"]},
    )

    assert pois.columns.tolist() == [
        "id",
        "osmid",
        "name",
        "osm_type",
        "category",
        "subcategory",
        "osm_key",
        "osm_value",
        "geometry",
    ]
    assert pois.loc[0, "name"] is None
    assert pois.loc[0, "category"] == "amenity"
    assert pois.loc[0, "osm_key"] == "amenity"
    assert pois.loc[0, "osm_value"] == "clinic"


def test_get_pois_osm_raises_on_empty_osm_tags():
    with pytest.raises(ValueError, match="osm_tags"):
        get_pois_osm(
            _aoi(),
            osm_tags={},
        )


def test_get_pois_osm_accepts_progress_bar(monkeypatch):
    monkeypatch.setattr(
        "accessx.poi.ox.features_from_polygon",
        lambda *args, **kwargs: _osm_features(),
    )

    pois = get_pois_osm(
        _aoi(),
        osm_tags={"amenity": ["clinic"]},
        show_progress=True,
    )

    assert len(pois) == 1


def test_get_pois_osm_accepts_whole_osm_tag_key(monkeypatch):
    monkeypatch.setattr(
        "accessx.poi.ox.features_from_polygon",
        lambda *args, **kwargs: _osm_features(),
    )

    pois = get_pois_osm(
        _aoi(),
        osm_tags={"amenity": True},
    )

    assert pois.loc[0, "category"] == "amenity"
    assert pois.loc[0, "subcategory"] == "clinic"
    assert pois.loc[0, "osm_key"] == "amenity"
    assert pois.loc[0, "osm_value"] == "clinic"


def test_get_pois_osm_accepts_custom_poi_groups(monkeypatch):
    monkeypatch.setattr(
        "accessx.poi.ox.features_from_polygon",
        lambda *args, **kwargs: _osm_features(),
    )

    pois, report = get_pois_osm(
        _aoi(),
        poi_groups={"healthcare": {"amenity": ["clinic"]}},
        return_report=True,
    )

    assert pois.loc[0, "category"] == "healthcare"
    assert pois.loc[0, "subcategory"] == "clinic"
    assert pois.loc[0, "osm_key"] == "amenity"
    assert pois.loc[0, "osm_value"] == "clinic"
    assert report["retrieved_counts"] == {"healthcare:amenity": 1}


def test_get_pois_osm_requires_one_query_mode():
    with pytest.raises(ValueError, match="exactly one"):
        get_pois_osm(_aoi())

    with pytest.raises(ValueError, match="exactly one"):
        get_pois_osm(
            _aoi(),
            osm_tags={"amenity": ["clinic"]},
            poi_groups={"healthcare": {"amenity": ["clinic"]}},
        )
